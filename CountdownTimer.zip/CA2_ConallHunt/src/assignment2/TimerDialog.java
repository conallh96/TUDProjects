package assignment2;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;


import assignment2.Timer;
import net.miginfocom.swing.MigLayout;


public class TimerDialog extends JDialog {
	
	// Represents the number of seconds that the countdown will be performed for.
	private long seconds;
	private Timer t;
	// Menu components.
	JTextField hourField, minField, secField;
	JLabel hourLabel, minLabel, secLabel;
	JButton startButton = new JButton("START");

	public TimerDialog(Timer owner, long seconds, boolean modality) {
		 
		super(owner, modality);
		t = owner;
		this.seconds = seconds;
		initComponents();
	}
	
	// Sets up display.
	private void initComponents() {
		setTitle("Initialise Timer");	
		setLayout(new BorderLayout());
		
		Font displayFont = new Font("Arial", Font.BOLD, 16);
		Font labelFont = new Font("Arial", Font.BOLD, 12);
		
		JPanel displayPanel = new JPanel(new GridLayout(1,3));
				
		JPanel hourPanel = new JPanel(new BorderLayout());
		hourField = new JTextField(5);
		hourField.setHorizontalAlignment(JTextField.CENTER);
		hourField.setFont(displayFont);
		hourField.setText("00");
		hourLabel = new JLabel("Hours");
		hourLabel.setHorizontalAlignment(JTextField.CENTER);
		hourLabel.setFont(labelFont);
		hourPanel.add(hourField, BorderLayout.CENTER);
		hourPanel.add(hourLabel, BorderLayout.SOUTH);
		
		displayPanel.add(hourPanel);
		
		JPanel minPanel = new JPanel(new BorderLayout());
		minField = new JTextField(5);
		minField.setHorizontalAlignment(JTextField.CENTER);
		minField.setFont(displayFont);
		minField.setText("00");
		minLabel = new JLabel("Minutes");
		minLabel.setHorizontalAlignment(JTextField.CENTER);
		minLabel.setFont(labelFont);
		minPanel.add(minField, BorderLayout.CENTER);
		minPanel.add(minLabel, BorderLayout.SOUTH);
		
		displayPanel.add(minPanel);
		
		JPanel secPanel = new JPanel(new BorderLayout());
		secField = new JTextField(5);
		secField.setHorizontalAlignment(JTextField.CENTER);
		secField.setFont(displayFont);
		secField.setText("00");
		secLabel = new JLabel("Seconds");
		secLabel.setHorizontalAlignment(JTextField.CENTER);
		secLabel.setFont(labelFont);
		secPanel.add(secField, BorderLayout.CENTER);
		secPanel.add(secLabel, BorderLayout.SOUTH);
		
		displayPanel.add(secPanel);
		
		add(displayPanel, BorderLayout.CENTER);
		
		JPanel buttonPanel = new JPanel();
		
		buttonPanel.add(startButton);
		
		hourField.addKeyListener(new KeyAdapter() { //add key listener to tickets number text field, only allowing numbers to be typed.
	 		   public void keyTyped(KeyEvent hourEnter) {
	 			      char num = hourEnter.getKeyChar();
	 			      if ( ((num < '0') || (num > '9')) && (num != KeyEvent.VK_BACK_SPACE)) {// if key typed is not between 0-9 ***OR A BACKSPACE****, delete the character and display warning.
	 			    	 hourEnter.consume();
	 						JOptionPane.showMessageDialog(TimerDialog.this, "You must enter numbers to set the countdown!","Warning Message",JOptionPane.WARNING_MESSAGE);
	 			      }
	 		   }
	 	});
		
		minField.addKeyListener(new KeyAdapter() { //add key listener to tickets number text field, only allowing numbers to be typed.
	 		   public void keyTyped(KeyEvent hourEnter) {
	 			      char num = hourEnter.getKeyChar();
	 			      if ( ((num < '0') || (num > '9')) && (num != KeyEvent.VK_BACK_SPACE)) {// if key typed is not between 0-9 ***OR A BACKSPACE****, delete the character and display warning.
	 			    	 hourEnter.consume();
	 						JOptionPane.showMessageDialog(TimerDialog.this, "You must enter numbers to set the countdown!","Warning Message",JOptionPane.WARNING_MESSAGE);
	 			      }
	 		   }
	 	});
		
		secField.addKeyListener(new KeyAdapter() { //add key listener to tickets number text field, only allowing numbers to be typed.
	 		   public void keyTyped(KeyEvent hourEnter) {
	 			      char num = hourEnter.getKeyChar();
	 			      if ( ((num < '0') || (num > '9')) && (num != KeyEvent.VK_BACK_SPACE)) {// if key typed is not between 0-9 ***OR A BACKSPACE****, delete the character and display warning.
	 			    	 hourEnter.consume();
	 						JOptionPane.showMessageDialog(TimerDialog.this, "You must enter numbers to set the countdown!","Warning Message",JOptionPane.WARNING_MESSAGE);
	 			      }
	 		   }
	 	});
	 	
	 	
		
		// TODO: This start action listener will be invoked when the start button is clicked.
		// It should take the values from the three text fields and try to convert them into integer values, and then check for NumberFormatExceptions 
		// and for the minute and second values between 0 and 59.
    	startButton.addActionListener(new ActionListener() {

    		@Override
    		public void actionPerformed(ActionEvent arg0) {
    			int mins;
    			int secs;
    			int hrs;
    			
    			
    			
    			if (hourField.getText().equals("")){
    				hrs=0;
    			}
    			else{
    			hrs = Integer.parseInt(hourField.getText());
    			hrs = (hrs*3600);
    			}
    			
    			
    			if (minField.getText().equals("")){
    				mins=0;
    			}
    			else{
    			 mins = Integer.parseInt(minField.getText());
    			mins = (mins*60);
    			}
    			
    			if (secField.getText().equals("")){
    				secs=0;
    			}
    			else{
    			 secs = Integer.parseInt(secField.getText());
    			}
    			if (secs > 59||mins > 3540){
    				JOptionPane.showMessageDialog(TimerDialog.this,
						    "Seconds and minutes must be between 0 and 59!","Warning Message",JOptionPane.WARNING_MESSAGE);
    			}
    			
    			else if (secs ==0 && mins ==0 && hrs == 0){
    				JOptionPane.showMessageDialog(TimerDialog.this,
						    "Cannot start a blank Timer!","Warning Message",JOptionPane.WARNING_MESSAGE);
    			}
    				
    				else{
    			
    			seconds = (hrs+mins+secs);
    			
    			
    			t.display.append("Countdown for: "+seconds+" seconds.\n");
    			dispose();
    				}
    			
    		}		
    	});
    	
    
		
		add(buttonPanel, BorderLayout.SOUTH);
		
		setSize(300, 150);
		setVisible(true);
		
	}
	
	public long getSeconds() {
		return (long)seconds;
	}

}

