
/**
 * Inheriting Class to create Drink items.
 *
 * @author (Conall Hunt - C17344203)
 */
public class Drink extends MenuItem
{
    // instance variables - replace the example below with your own
    private boolean alcohol = false;
    

    public Drink()
    {
        this.alcohol = false;
        
    }

    public Drink(String name, String mainIngredient, double price, int stock, boolean alcohol)
    {
        // initialise instance variables
        super(name, mainIngredient, price, stock);
        this.alcohol = alcohol;
        

    }

    public boolean getalcohol()
    {
        return this.alcohol;
    }
    
    public void display()
    {
        System.out.println("");
        System.out.println("Here are the Drink's details");
        super.display();

        if (alcohol)
        {
            System.out.println("This is an alcoholic drink and thus a tax of 12.5% has been added onto the cost price");
            System.out.println("You must be over the age of 18 to order this drink");
        }
        else 
        {
            System.out.println("This is a non-alcoholic drink");
        }

    }
}
