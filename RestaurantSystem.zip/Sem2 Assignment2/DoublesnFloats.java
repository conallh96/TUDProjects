
/**
 * Driver class for restaurant "Doubles 'n' Floats".
 *
 * @author (Conall Hunt - C17344203) 
 */

//COMMENTS FOR PSD DIFFERENCES SINCE DATE OF SUBMISSION
// 1. I originally had two seperate array lists for both food and drink. Upon realisation that the main point of 
// inheritance is to store different objects together, this was ammended to just one array list.
// This has led to some very slight differences, which actually lead to smoother code, such as not having to as if
// they are looking fro food or drink items.
// 2. There was previosuly an istance variable in the Drink object with a double for alcohol tax, however, once 
// the dat file was created, this would be multiplied infinitely rather than jusat once, this has now been used in the driver.
// 3. The Initiation module was no longer required as file checking was done in driver and subsequent initiation done by calling addFood and addDrink Modules.
import java.util.*;
import java.io.*;
import java.text.DecimalFormat;
public class DoublesnFloats
{
    ArrayList<MenuItem> menu;
    Double customerTotal;
    int numberItems;
    public DoublesnFloats()
    {
        System.out.print("\f");
        menu = new ArrayList<MenuItem>();
        Calendar c = Calendar.getInstance();
        Calendar night = Calendar.getInstance();
        night.set(Calendar.HOUR_OF_DAY, 4);
        Calendar morn = Calendar.getInstance();
        morn.set(Calendar.HOUR_OF_DAY, 12);
        Calendar eve = Calendar.getInstance();
        eve.set(Calendar.HOUR_OF_DAY, 17);
        Calendar late = Calendar.getInstance();
        late.set(Calendar.HOUR_OF_DAY, 23);
        if (c.get(c.HOUR_OF_DAY) >= eve.get(eve.HOUR_OF_DAY))
        {
            System.out.println("Good Evening and Welcome to Doubles 'n' Floats!");
        }

        else if (c.get(c.HOUR_OF_DAY) >= morn.get(morn.HOUR_OF_DAY))
        {
            System.out.println("Good Afternoon and Welcome to Doubles 'n' Floats!");
        }

        else if ( c.get(c.HOUR_OF_DAY) >= night.get(night.HOUR_OF_DAY))
        {
            System.out.println("Good Morning and Welcome to Doubles 'n' Floats!");
        }

        else 
        {
            System.out.println("Oh! Somebody's here! Take a seat!");
        }


        if (readFromFile()== true)  //menu items have already been created
        {
            System.out.println("There are previous products in the database!");

        }
        else //there are no items to be found so user has to input them
        {
            //1.2 If no, ask user to add two of each.

            for (int i = 0; i < 2; i ++)
            {
                System.out.println("");
                System.out.println("Please enter Food Item No."+(i+1));
                addFood();
            }

            for (int i = 0; i < 2; i ++)
            {
                System.out.println("");
                System.out.println("Please enter Drink Item No."+(i+1));
                addDrink();
            }

        }   
        mainMenu();
        saveToFile();
    }
    //2. Main Menu
    public void mainMenu()
    {
        Scanner scan= new Scanner(System.in);

        int answer=0;

        do
        {
            System.out.println("");
            String divider ="----------------------------------------";
            System.out.println("");
            System.out.println(divider);
            System.out.println("1. Staff Menu");
            System.out.println("2. Customer Menu");
            System.out.println("3. See ya Later!");

            System.out.println(divider);

            System.out.print("Please select the number corresponding to which service you wish to use:");
            answer= scan.nextInt();
            // Determine which option chosen - Ask user which option to use and call corresponding method
            // I was advised in lab that code for validation of a string entered when int required was not expected of us yet. 

            if (answer==1)
            {
                System.out.println("");
                System.out.println("Welcome to the Staff Menu!");
                staffMenu();

            }
            else if (answer==2) 
            {
                System.out.println("");
                customerTotal = 0.0;
                System.out.println("Ready to see what we got?");
                customerMenu();

            }
            else if (answer==3) //Exit System
            {
                System.out.println("");
                System.out.println("THANKS FOR STOPPING BY WE HOPE TO SEE YOU SOON!");
                //System.exit(0);
            }
            else 
            {
                System.out.println("");
                System.out.println("Please choose a valid option.");
            }
        } while (answer != 3 );
    }
    //2.1 Staff Menu
    public void staffMenu()
    {
        Scanner scan= new Scanner(System.in);

        int answer=0;
        do
        {
            System.out.println("");
            String divider ="----------------------------------------";
            System.out.println("");
            System.out.println(divider);
            System.out.println("1. Add a new Food Item to our Menu");
            System.out.println("2. Add a new Drink to our Menu");
            System.out.println("3. Add Stock to an Item we already serve");
            System.out.println("4. Return to Main Menu");
            System.out.println(divider);

            System.out.print("Please select the number corresponding to which service you wish to use:");
            answer= scan.nextInt();
            // Determine which option chosen - Ask user which option to use and call corresponding method
            // I was advised in lab that code for validation of a string entered when int required was not expected of us yet. 

            if (answer==1)
            {
                System.out.println("");
                System.out.println("You chose to add a Food Item to the Menu");
                addFood();

            }
            else if (answer==2) 
            {
                System.out.println("");
                System.out.println("You chose to add a Food Item to the Menu");
                addDrink();

            }
            else if (answer==3) 
            {
                System.out.println("");
                System.out.println("You have chosen to add Stock to an existing Menu Item");
                addStock();
            }
            else if (answer==4) 
            {
                System.out.println("");
                System.out.println("Returning to Main Menu");

            }
            else 
            {
                System.out.println("");
                System.out.println("Please choose a valid option.");
            }
        } while (answer!= 4);
    }
    //2.2 Customer Menu
    public void customerMenu()
    {
        Scanner scan= new Scanner(System.in);

        int answer=0;
        do
        {
            String divider ="----------------------------------------";
            System.out.println("");
            System.out.println(divider);
            System.out.println("1. Browse Menu");
            System.out.println("2. Browse Drinks Menu");
            System.out.println("3. Order Food" );
            System.out.println("4. Order Drinks");
            System.out.println("5. View Special Offers");
            System.out.println("6. Return to Main Menu ");
            System.out.println(divider);

            System.out.print("Please select the number corresponding to which service you wish to use:");
            answer= scan.nextInt();
            // Determine which option chosen - Ask user which option to use and call corresponding method
            // I was advised in lab that code for validation of a string entered when int required was not expected of us yet. 

            if (answer==1)
            {
                System.out.println("");
                System.out.println("Feast your eyes on what we've got in store!");
                foodMenu();

            }
            else if (answer==2)
            {
                System.out.println("");
                System.out.println("Thirsty? We've got you covered!");
                drinkMenu();

            }
            else if (answer==3)
            {
                System.out.println("");
                System.out.println("What can we get you?");
                foodPick();

            }
            else if (answer==4)
            {
                System.out.println("");
                System.out.println("Drown your Sorrows!");
                drinkPick();

            }
            else if (answer==5)
            {
                System.out.println("");
                System.out.println("Why not go for a unique Meal Deal?");
                deals();
            }
            else if (answer==6) 
            {
                System.out.println("");
                System.out.println("Returning to Main Menu");

            }
            else {
                System.out.println("");
                System.out.println("Please select a correct option.");
            }
        } while (answer!=6);
    }
    //2.1.1 Add Food Item
    public void addFood()
    {
        Scanner scan= new Scanner(System.in);

        String name;
        String mainIngredient;
        double price = 0;
        int stock;
        boolean glutenFree;
        String cuisine;
        String glutAnswer;
        String extra1;
        String extra2;
        String extra3;

        System.out.print("What is the name of the new dish?");
        name = scan.nextLine();
        System.out.print("What is the main ingredient?");
        mainIngredient = scan.nextLine();
        System.out.print("Is the dish Gluten Free? (Yes/No)");
        glutAnswer = scan.nextLine();

        if (glutAnswer.equalsIgnoreCase ("yes") || glutAnswer.equalsIgnoreCase ("y"))
        {
            glutenFree = true;
        }
        else 
        {
            glutenFree = false;
        }
        System.out.print("What cuisine does the dish belong to?");
        cuisine = scan.nextLine();
        System.out.print("What quantity does the restaurant have in stock?");
        stock = scan.nextInt();
        scan.nextLine();
        System.out.print("How much will the basic dish cost?");
        price = scan.nextDouble();
        scan.nextLine();
        System.out.print("");
        System.out.println("What 3 extras will the Customer be able to add?");
        System.out.print("Extra 1:");
        extra1 = scan.nextLine();
        System.out.print("Extra 2:");
        extra2 = scan.nextLine();
        System.out.print("Extra 3:");
        extra3 = scan.nextLine();
        Food foodItem;
        foodItem = new Food (name, mainIngredient, price, stock, glutenFree, cuisine, extra1, extra2, extra3);
        menu.add(foodItem);
    }
    //2.1.2 Add Drink Item
    public void addDrink()
    {
        Scanner scan= new Scanner(System.in);

        String name;
        String mainIngredient;
        double price = 0;
        int stock;
        boolean alcohol = false;
        String alcAnswer;
        double alcoholTax = 0.125;
        System.out.print("What is the name of the new Drink?");
        name = scan.nextLine();
        System.out.print("What is the main ingredient?");
        mainIngredient = scan.nextLine();
        System.out.print("Is the drink Alcoholic? (Yes/No)");
        alcAnswer = scan.nextLine();

        if (alcAnswer.equalsIgnoreCase ("yes") || alcAnswer.equalsIgnoreCase ("y"))
        {
            alcohol = true;
        }

        System.out.print("How many of these drinks do we have in Stock?");
        stock = scan.nextInt();
        scan.nextLine();

        System.out.print("What is the base price of the drink?");
        price = scan.nextDouble();
        scan.nextLine();

        if (alcohol)
        {
            price = price + (price * alcoholTax);
        }

        Drink drinkItem;
        drinkItem = new Drink (name, mainIngredient, price, stock, alcohol);
        menu.add(drinkItem);
    }
    //2.1.3 Add Stock to Item
    public void addStock()
    {
        Scanner scan = new Scanner(System.in);

        String name;
        MenuItem item = null;

        System.out.print("\nWhat is the name of the item you wish to add to? ");
        name = scan.nextLine();

        for (MenuItem f : menu)
        {
            if (f.getName().equalsIgnoreCase(name))
                item = f;
        }

        int numberAdd;
        if (item != null)
        {
            System.out.print("How many " + item.getName() + "(s) do you wish to add to the inventory? ");
            numberAdd = scan.nextInt();
            scan.nextLine();

            System.out.println(numberAdd + "have been added to stock");
            item.setStock(item.getStock() + numberAdd);

        }
        else
            System.out.println("This item is not on our Menu"); 
    }
    //2.2.1 Browse Menu
    public void foodMenu()
    {
        for (MenuItem f : menu)
        {
            if (f instanceof Food)
                f.display();
        }
    }
    //2.2.2 Browse Drinks Menu
    public void drinkMenu()
    {
        for (MenuItem d : menu)
        {
            if (d instanceof Drink)
                d.display();
        }
    }
    //2.2.3 Order Food
    public void foodPick()
    {
        Scanner scan = new Scanner(System.in);
        DecimalFormat cost = new DecimalFormat("#.##");
        foodMenu();
        System.out.println("");
        String name;
        Food item = null;
        int numberOrder;
        double total;

        System.out.print("\nWhat is the name of the dish you would like to order? ");
        name = scan.nextLine();

        for (MenuItem f : menu)
        {
            if (f.getName().equalsIgnoreCase(name))
                item = (Food)f;
        }

        if (item != null)
        {
            System.out.print("How many " + item.getName() + "(s) do you wish to add to order? ");
            numberOrder = scan.nextInt();
            scan.nextLine();

            if (numberOrder <= item.getStock())
            {
                int extras = 0;
                int answer = 0;
                String choice;

                System.out.println(numberOrder + item.getName() + "have been ordered!");
                item.setStock(item.getStock() - numberOrder);

                System.out.println("Would you like to add any of our three extras? You can add as many times as you like! (Yes/No)");
                choice = scan.nextLine();

                if (choice.equalsIgnoreCase("yes"))
                {

                    System.out.println("1. " + item.getExtra1());
                    System.out.println("2. " + item.getExtra2());
                    System.out.println("3. " + item.getExtra3());
                    System.out.println("4. No More Extras");

                    do{
                        System.out.print("Enter the number corresponding to the option you would like");
                        answer = scan.nextInt();
                        if (answer == 1)
                        { 
                            extras++;
                            System.out.println(item.getExtra1() + " was added for an extra €1.50 per dish!");
                        }
                        else if (answer == 2)
                        { 
                            extras++;
                            System.out.println(item.getExtra2() + " was added for an extra €1.50 per dish!");
                        }
                        else if (answer == 3)
                        { 
                            extras++;
                            System.out.println(item.getExtra3() + " was added for an extra €1.50 per dish!");
                        }
                        else if (answer == 4)
                        { 
                            System.out.println("We'll whip that right up!");
                        }
                        else 
                        {
                            System.out.println("Please pick a valid option!");
                        }

                    } while (answer != 4);
                    total = ((item.getPrice() + (extras * 1.50) )* numberOrder);
                    customerTotal = customerTotal + total;
                    System.out.println("");
                    System.out.println("Perfect! €" + cost.format(total) + " has been added to your total!");
                    System.out.println("Your Total is €" + cost.format(customerTotal));
                }

                else 
                {
                    System.out.println("");
                    System.out.println("No extras, got it!");
                    total = item.getPrice() * numberOrder;
                    customerTotal = customerTotal + total;
                    System.out.println("Perfect! €" + cost.format(total) + " has been added to your total!");
                    System.out.println("Your Total is €" + cost.format(customerTotal));
                }
            }
            else if (numberOrder > item.getStock())
                System.out.println("Sorry we don't have enough! Please order less or choose a different item from the Menu!");

        }

        else
            System.out.println("Sorry we don't have that item on our Menu!"); 

    }
    //2.2.4 Order Drinks
    public void drinkPick()
    {
        Scanner scan = new Scanner(System.in);
        DecimalFormat cost = new DecimalFormat("#.##");

        System.out.println("");
        drinkMenu();
        System.out.println("");
        String name;
        Drink item = null;
        int numberOrder = 0;
        double total;

        System.out.print("\nWhat is the name of the Drink you would like to order? ");
        name = scan.nextLine();

        for (MenuItem d : menu)
        {
            if (d.getName().equalsIgnoreCase(name))
                item = (Drink)d;
        }

        if (item != null)
        {
            System.out.print("How many " + item.getName() + "(s) do you wish to add to order? ");
            numberOrder = scan.nextInt();
            scan.nextLine();

            if (numberOrder <= item.getStock())
            {

                System.out.println(numberOrder + item.getName() + "have been ordered!");
                item.setStock(item.getStock() - numberOrder);

                total = item.getPrice() * numberOrder;
                customerTotal = customerTotal + total;
                System.out.println("Perfect! €" + cost.format(total) + " has been added to your total!");
                System.out.println("Your Total is €" + cost.format(customerTotal));
            }
        }
        else if (numberOrder > item.getStock())
            System.out.println("Sorry we don't have enough! Please order less or choose a different item from the Menu!");

        else
            System.out.println("Sorry we don't have that item on our Menu!"); 
    }
    //2.2.5 View Special Offers
    public void deals()
    {
        Scanner scan = new Scanner(System.in);
        Calendar c = Calendar.getInstance();
        Calendar night = Calendar.getInstance();
        night.set(Calendar.HOUR_OF_DAY, 4);
        Calendar morn = Calendar.getInstance();
        morn.set(Calendar.HOUR_OF_DAY, 12);
        Calendar eve = Calendar.getInstance();
        eve.set(Calendar.HOUR_OF_DAY, 17);
        Calendar late = Calendar.getInstance();
        late.set(Calendar.HOUR_OF_DAY, 23);
        Random randomVariable = new Random();
        DecimalFormat cost = new DecimalFormat("#.##");
        int number1;
        int number2;
        double discount = 0.75;

        if (c.get(c.HOUR_OF_DAY) >= eve.get(eve.HOUR_OF_DAY))
        {
            System.out.println("We can't believe it took you all day to get here! Quick grab some dinner!");
        }

        else if (c.get(c.HOUR_OF_DAY) >= morn.get(morn.HOUR_OF_DAY))
        {
            System.out.println("Can't wait till dinner? One of our Lunch Deals will be sure to hit the spot!");
        }

        else if ( c.get(c.HOUR_OF_DAY) >= night.get(night.HOUR_OF_DAY))
        {
            System.out.println("Why not take a look at one of our 'Early Riser' deals?");
        }

        else 
        {
            System.out.println("It's late.... you must be hungry!");
        }

        do {

            do
            {
                number1 = randomVariable.nextInt(menu.size());
            } while (menu.get(number1) instanceof Drink);

            do
            {
                number2 = randomVariable.nextInt(menu.size());
            } while (menu.get(number2) instanceof Food);
        } while (menu.get(number1).getStock() < 1 || menu.get(number2).getStock() < 1);

        double originalPrice = menu.get(number1).getPrice() + menu.get(number2).getPrice();
        double dealPrice = originalPrice * discount;
        System.out.println("");
        System.out.println("With this offer, you will get a basic " + menu.get(number1).getName() + " dish and a " + menu.get(number2).getName() + " for just €" + cost.format(dealPrice) + "!");
        System.out.println("That's a huge saving of €" + cost.format((originalPrice - dealPrice))  + "!");
        System.out.println("");
        System.out.print("Would you like to go ahead with this deal? (Yes/No)");
        String answer = scan.nextLine();

        if (answer.equalsIgnoreCase("yes") || answer.equalsIgnoreCase("y"))
        {
            System.out.println("");
            System.out.println("Wonderful choice! The offer has been ordered and €" + cost.format(dealPrice) + " has been added to your total!");
            customerTotal = customerTotal + dealPrice;
            menu.get(number1).setStock(menu.get(number1).getStock()-1);
            menu.get(number2).setStock(menu.get(number2).getStock()-1);
            System.out.println("Your total is now €" + cost.format(customerTotal) +".");

        }
        else 
        {
            System.out.println("");
            System.out.println("No problem, we will bring you back to the menu!");
        }

    }
    //3. Save Menu Items to file.
    public void saveToFile()
    {
        String fileName;
        ObjectOutputStream fileOut;
        /*System.out.print("Enter filename: ");
        Scanner scan = new Scanner(System.in);
        fileName = scan.nextLine(); */
        try{
            fileOut = new ObjectOutputStream(new FileOutputStream("menu.dat"));
            for (MenuItem item : menu)
            {
                fileOut.writeObject(item);
            }
            fileOut.close();
        }
        catch (IOException e)
        {
            System.out.println("Not enough free space, please contact IT services");
        }
    }
    //1. Check if Stock items already saved to File
    public boolean readFromFile()
    {
        int index=0;
        String fileName;
        ObjectInputStream fileIn;
        MenuItem anItem;

        /* System.out.print("Enter filename: ");
        Scanner scan = new Scanner(System.in);
        fileName = scan.nextLine();*/

        try{
            fileIn = new ObjectInputStream(new FileInputStream("menu.dat"));
            anItem = (MenuItem) fileIn.readObject();
            index = 1;
            //1.1 If yes, load to program
            while (anItem != null)
            {
                menu.add(anItem);
                anItem = (MenuItem) fileIn.readObject();
                index++;
            }
            fileIn.close();
            return true;
        }
        catch (IOException e)//this will be called if a) file doesn't exist or
        //b) it has reached the end of the file
        {
            if (index > 0) //there were accounts in the file 
            {

                return true; 
            }
            else //file doesn't exist
            { System.out.println("No Menu Items have been created yet, you will need to create some\n");
                return false;
            }
        }

        catch (ClassNotFoundException e)
        {
            System.out.println("Class Error : " + e.getMessage());
            return false;
        }
    }//end saveToFile

    public static void main(String[] args)
    {
        new DoublesnFloats();
    }
}
