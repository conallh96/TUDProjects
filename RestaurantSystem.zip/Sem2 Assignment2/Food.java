
/**
 * Inheriting Class to create food items.
 *
 * @author (Conall Hunt - C17344203)

 */
public class Food extends MenuItem
{
    // instance variables - replace the example below with your own
    private boolean glutenFree;
    private String cuisine;
    private String extra1;
    private String extra2;
    private String extra3;

    /**
     * Constructor for objects of class Food
     */
    public Food()
    {
        // initialise instance variables
        this.glutenFree = false;
        this.cuisine = "";
        this.extra1 = "";
        this.extra2 = "";
        this.extra3 = "";

    }
    public Food(String name, String mainIngredient, double price, int stock, boolean glutenFree, String cuisine, String extra1, String extra2, String extra3)
    {
        // initialise instance variables
        super(name, mainIngredient, price, stock);
        this.glutenFree = glutenFree;
        this.cuisine = cuisine;
        this.extra1 = extra1;
        this.extra2 = extra2;
        this.extra3 = extra3;

    }
    public String getCuisine()
    {
        return this.cuisine;
    }

    public String getExtra1()
    {
        return this.extra1;
    }

    public String getExtra2()
    {
        return this.extra2;
    }

    public String getExtra3()
    {
        return this.extra3;
    }

   

    public void display()
    {
        System.out.println("");
        System.out.println("Here are the Dish's details");
        System.out.println("");
        super.display();
        System.out.println("The Dish is of "+this.cuisine+" descent.");

        if (glutenFree == true)
        {
            System.out.println("This is a Gluten Free with no comprimise on flavour!");
        }
        else if  (glutenFree == false)
        {
            System.out.println("This dish contains Gluten, but is worth it.");
        }

        
        System.out.println("The available extras are:");
        System.out.println("1."+this.extra1);
        System.out.println("2."+this.extra2);
        System.out.println("3."+this.extra3);
    }
}
