import java.io.*;
/**
 * Abstract class MenuItem - Super Class for Restaurant
 *
 * @author (Conall Hunt - C17344203)

 */
public abstract class MenuItem implements Serializable
{
    // instance variables 
    protected String name;
    protected String mainIngredient;
    protected double price;
    protected int stock;

    public MenuItem()
    {
        this.name = "";
        this.mainIngredient = "";
        this.price = 0;
        this.stock = 0;
    }

    public MenuItem(String name, String mainIngredient, double price, int stock)
    {
        this.name = name;
        this.mainIngredient = mainIngredient;
        this.price = price;
        this.stock = stock;
    }

    public String getName()
    {
        return this.name;
    }

    public String getMainIngredient()
    {
        return this.mainIngredient;
    }

    public double getPrice()
    {
        return this.price;
    }

    public int getStock()
    {
        return this.stock;
    }
    
    public void setName(String name)
    {
        this.name = name;
    }

    public void setMainIngredient(String mainIngredient)
    {
        this.mainIngredient = mainIngredient;
    }

    public void setPrice (double price)
    {
        this.price = price;
    }
    
    public void setStock (int stock)
    {
        this.stock = stock;
    }


    public void display()
    {
        
        
        System.out.println("Item Name : "+  this.name);
        System.out.println("The main ingredient in this item is " + this.mainIngredient);
        System.out.println(this.name +" will cost: €" + this.price);
        System.out.println("There are : "+  this.stock + " units available in stock.");
    }

}
